<?php /* Smarty version 3.1.24, created on 2017-01-24 08:08:11
         compiled from "/var/www/html/lucy/public/_template/front/testimonials.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:4649539635886fd5bed79f0_50565464%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7997a3afdf26a09fdfd60c5fe80921f39e0f89ec' => 
    array (
      0 => '/var/www/html/lucy/public/_template/front/testimonials.tpl',
      1 => 1485241688,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4649539635886fd5bed79f0_50565464',
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_5886fd5bed82c5_59284491',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5886fd5bed82c5_59284491')) {
function content_5886fd5bed82c5_59284491 ($_smarty_tpl) {

}
}
?>