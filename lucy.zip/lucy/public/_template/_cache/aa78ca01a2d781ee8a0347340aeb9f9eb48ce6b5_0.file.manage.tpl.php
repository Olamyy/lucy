<?php /* Smarty version 3.1.24, created on 2017-01-15 08:48:46
         compiled from "public/_template/front-theme/registry/manage.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:1604299288587b295e654fc3_00411508%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'aa78ca01a2d781ee8a0347340aeb9f9eb48ce6b5' => 
    array (
      0 => 'public/_template/front-theme/registry/manage.tpl',
      1 => 1484466464,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1604299288587b295e654fc3_00411508',
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_587b295e656708_93422100',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_587b295e656708_93422100')) {
function content_587b295e656708_93422100 ($_smarty_tpl) {

}
}
?>