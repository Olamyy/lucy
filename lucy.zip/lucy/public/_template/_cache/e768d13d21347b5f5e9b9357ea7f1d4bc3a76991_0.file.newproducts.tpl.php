<?php /* Smarty version 3.1.24, created on 2017-05-23 20:32:48
         compiled from "/home/terragon/Sites/lucy/public/_template/front/newproducts.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:107024136959248e60431421_96824011%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e768d13d21347b5f5e9b9357ea7f1d4bc3a76991' => 
    array (
      0 => '/home/terragon/Sites/lucy/public/_template/front/newproducts.tpl',
      1 => 1495567966,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '107024136959248e60431421_96824011',
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_59248e60431e50_11814114',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_59248e60431e50_11814114')) {
function content_59248e60431e50_11814114 ($_smarty_tpl) {

}
}
?>