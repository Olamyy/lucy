<?php /* Smarty version 3.1.24, created on 2017-02-14 20:49:44
         compiled from "/var/www/html/lucyregistry/public/_template/front/registry/couple/dashboard/wizard.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:29420857358a35f582d8413_18749354%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a5d324e0a08738cba59f8a193b65036c3b790647' => 
    array (
      0 => '/var/www/html/lucyregistry/public/_template/front/registry/couple/dashboard/wizard.tpl',
      1 => 1487096653,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '29420857358a35f582d8413_18749354',
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_58a35f5833d867_04218746',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_58a35f5833d867_04218746')) {
function content_58a35f5833d867_04218746 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '29420857358a35f582d8413_18749354';
?>
<div class="sidebar-widget product-tag wow fadeInUp">
    <h3 class="section-title">Registry TODO</h3>
    <div class="sidebar-widget-body outer-top-xs">
        <ul>
            <li class="tag-list">
                <a class="item" title="Phone" >Upload A Couple Photo</a>
            </li>
            <li class="tag-list">
                <a class="item" title="Phone" >Add Gifts</a>
            </li>
            <li class="tag-list">
                <a class="item" title="Phone" >Setup Shipping</a>
            </li>
            <li class="tag-list">
                <a class="item" title="Phone" >Invite Partner</a>
            </li>
            <li class="tag-list">
                <a class="item" title="Phone" >Go Live</a>
            </li>
            <li class="tag-list">
                <a class="item" title="Phone" >Receive Gifts</a>
            </li>
        </ul>
        
        <!-- /.tag-list -->
    </div>
    <!-- /.sidebar-widget-body -->
</div><?php }
}
?>