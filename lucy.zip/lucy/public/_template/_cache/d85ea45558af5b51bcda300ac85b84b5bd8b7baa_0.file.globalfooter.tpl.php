<?php /* Smarty version 3.1.24, created on 2017-05-16 12:26:22
         compiled from "/home/terragon/Sites/lucy/public/_template/admin/globalfooter.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:1150609078591ae1deba5935_82261369%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd85ea45558af5b51bcda300ac85b84b5bd8b7baa' => 
    array (
      0 => '/home/terragon/Sites/lucy/public/_template/admin/globalfooter.tpl',
      1 => 1494871087,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1150609078591ae1deba5935_82261369',
  'variables' => 
  array (
    'BASE_URL' => 0,
    'SMARTY_VIEW_FOLDER' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_591ae1debce687_80329647',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_591ae1debce687_80329647')) {
function content_591ae1debce687_80329647 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '1150609078591ae1deba5935_82261369';
?>
<!-- /#wrap -->
<!-- global scripts-->
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;
echo $_smarty_tpl->tpl_vars['SMARTY_VIEW_FOLDER']->value;?>
/admin/assets/js/components.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;
echo $_smarty_tpl->tpl_vars['SMARTY_VIEW_FOLDER']->value;?>
/admin/assets/js/custom.js"><?php echo '</script'; ?>
>
<!-- global scripts end-->
<?php }
}
?>