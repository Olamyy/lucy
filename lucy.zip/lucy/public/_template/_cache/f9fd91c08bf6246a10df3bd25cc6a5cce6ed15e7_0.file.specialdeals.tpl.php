<?php /* Smarty version 3.1.24, created on 2017-02-14 19:29:32
         compiled from "/var/www/html/lucyregistry/public/_template/front/specialdeals.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:84563413258a34c8c2031f3_37571237%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f9fd91c08bf6246a10df3bd25cc6a5cce6ed15e7' => 
    array (
      0 => '/var/www/html/lucyregistry/public/_template/front/specialdeals.tpl',
      1 => 1487096653,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '84563413258a34c8c2031f3_37571237',
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_58a34c8c203bf5_57727021',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_58a34c8c203bf5_57727021')) {
function content_58a34c8c203bf5_57727021 ($_smarty_tpl) {

}
}
?>