<?php /* Smarty version 3.1.24, created on 2017-05-25 05:08:13
         compiled from "/home/terragon/Sites/lucy/public/_template/front/mainsliders.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:2130636678592658ad46bca3_48397785%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '440461c51614a405a2377e4373ed292265dfd44b' => 
    array (
      0 => '/home/terragon/Sites/lucy/public/_template/front/mainsliders.tpl',
      1 => 1495685269,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2130636678592658ad46bca3_48397785',
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_592658ad51e7c2_87666941',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_592658ad51e7c2_87666941')) {
function content_592658ad51e7c2_87666941 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '2130636678592658ad46bca3_48397785';
?>

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div id="hero">
        <div id="owl-main" class="owl-carousel owl-inner-nav owl-ui-sm">
            <div class="item" style="background-image: url(http://placehold.it/840x800);">
                <div class="container-fluid">
                    <div class="caption bg-color vertical-center text-left">
                        <div class="button-holder fadeInDown-3 margin15_bottom"> <a href=""
                             class="btn-lg btn btn-uppercase main-slider btn-primary shop-now-button">Create Your Registry</a> </div>
                    </div>
                    <!-- /.caption -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /.item -->

            <div class="item" style="background-image: url(http://placehold.it/840x340);">
                <div class="container-fluid">
                    <!-- /.caption -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /.item -->

        </div>
        <!-- /.owl-carousel -->
    </div>

    <br>
    <br>
    <br>
    <br>
<?php }
}
?>