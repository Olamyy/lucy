<?php /* Smarty version 3.1.24, created on 2017-02-21 12:47:34
         compiled from "/var/www/html/lucy/public/_template/front/mainsliders.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:208193910858ac28d6cb74c7_68049128%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '192f713b02c2124546df60557634eb20c1eaab55' => 
    array (
      0 => '/var/www/html/lucy/public/_template/front/mainsliders.tpl',
      1 => 1487677328,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '208193910858ac28d6cb74c7_68049128',
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_58ac28d6cbafd4_58291817',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_58ac28d6cbafd4_58291817')) {
function content_58ac28d6cbafd4_58291817 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '208193910858ac28d6cb74c7_68049128';
?>

<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
    <div id="hero">
        <div id="owl-main" class="owl-carousel owl-inner-nav owl-ui-sm">
            <div class="item" style="background-image: url(http://placehold.it/840x340);">
                <div class="container-fluid">
                    <div class="caption bg-color vertical-center text-left">
                    </div>
                    <!-- /.caption -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /.item -->

            <div class="item" style="background-image: url(http://placehold.it/840x340);">
                <div class="container-fluid">
                    <!-- /.caption -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /.item -->

        </div>
        <!-- /.owl-carousel -->
    </div>
<?php }
}
?>