<?php /* Smarty version 3.1.24, created on 2017-05-25 15:16:22
         compiled from "public/_template/front/store.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:6982900205926e736e85eb0_07704032%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b59718695ab3e42b3112c452b7f26dd74df76cc9' => 
    array (
      0 => 'public/_template/front/store.tpl',
      1 => 1495721780,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6982900205926e736e85eb0_07704032',
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_5926e736e97519_44230091',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5926e736e97519_44230091')) {
function content_5926e736e97519_44230091 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '6982900205926e736e85eb0_07704032';
echo $_smarty_tpl->getSubTemplate ('./header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


<?php echo $_smarty_tpl->getSubTemplate ("./navmenu.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>




<?php echo $_smarty_tpl->getSubTemplate ("./side.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


<?php echo $_smarty_tpl->getSubTemplate ("./mainsliders.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


<?php echo $_smarty_tpl->getSubTemplate ("./newarrivals.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


<?php echo $_smarty_tpl->getSubTemplate ("./footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>