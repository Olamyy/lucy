<?php /* Smarty version 3.1.24, created on 2017-05-23 21:47:51
         compiled from "/home/terragon/Sites/lucy/public/_template/front/side.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:207659136959249ff723fd84_27833268%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9eba8939352e0a0af97a2f8ce99f610790b3c5ea' => 
    array (
      0 => '/home/terragon/Sites/lucy/public/_template/front/side.tpl',
      1 => 1495572111,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '207659136959249ff723fd84_27833268',
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_59249ff7249409_47052985',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_59249ff7249409_47052985')) {
function content_59249ff7249409_47052985 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '207659136959249ff723fd84_27833268';
?>
<div class="body-content outer-top-vs" id="top-banner-and-menu">
    <div class="container">
        <div class="row">
            <div class="row">
                <!-- ============================================== SIDEBAR ============================================== -->
                <div class="col-xs-12 col-sm-12 col-md-12 ">
                    <?php echo $_smarty_tpl->getSubTemplate ("./hotdeals.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

                    
                    
<?php }
}
?>