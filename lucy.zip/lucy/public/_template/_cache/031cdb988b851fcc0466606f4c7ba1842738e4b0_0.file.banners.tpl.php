<?php /* Smarty version 3.1.24, created on 2017-05-15 19:36:01
         compiled from "/home/terragon/Sites/lucy/public/_template/front/banners.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:151257765919f5118f21a8_89200272%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '031cdb988b851fcc0466606f4c7ba1842738e4b0' => 
    array (
      0 => '/home/terragon/Sites/lucy/public/_template/front/banners.tpl',
      1 => 1494871087,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '151257765919f5118f21a8_89200272',
  'variables' => 
  array (
    'BASE_URL' => 0,
    'SMARTY_VIEW_FOLDER' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_5919f5119a3927_53107160',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5919f5119a3927_53107160')) {
function content_5919f5119a3927_53107160 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '151257765919f5118f21a8_89200272';
?>

<div class="wide-banners wow fadeInUp outer-bottom-xs">
    <div class="row">
        <div class="col-md-7 col-sm-7">
            <div class="wide-banner cnt-strip">
                <div class="image"> <img class="img-responsive" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;
echo $_smarty_tpl->tpl_vars['SMARTY_VIEW_FOLDER']->value;?>
/front/assets/images/banners/home-banner1.jpg" alt=""> </div>
            </div>
            <!-- /.wide-banner -->
        </div>
        <!-- /.col -->
        <div class="col-md-5 col-sm-5">
            <div class="wide-banner cnt-strip">
                <div class="image"> <img class="img-responsive" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;
echo $_smarty_tpl->tpl_vars['SMARTY_VIEW_FOLDER']->value;?>
/front/assets/images/banners/home-banner2.jpg" alt=""> </div>
            </div>
            <!-- /.wide-banner -->
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->
</div>
<!-- /.wide-banners -->


<!-- /.homebanner-holder -->
<!-- ============================================== CONTENT : END ============================================== -->
</div>
<?php }
}
?>