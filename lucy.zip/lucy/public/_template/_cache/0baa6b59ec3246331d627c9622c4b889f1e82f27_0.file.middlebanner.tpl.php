<?php /* Smarty version 3.1.24, created on 2017-05-15 19:36:01
         compiled from "/home/terragon/Sites/lucy/public/_template/front/middlebanner.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:9129347605919f511cb96d3_77011451%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0baa6b59ec3246331d627c9622c4b889f1e82f27' => 
    array (
      0 => '/home/terragon/Sites/lucy/public/_template/front/middlebanner.tpl',
      1 => 1494871087,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9129347605919f511cb96d3_77011451',
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_5919f511da2552_59914964',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5919f511da2552_59914964')) {
function content_5919f511da2552_59914964 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '9129347605919f511cb96d3_77011451';
?>
<div class="wide-banners wow fadeInUp outer-bottom-xs">
    <div class="row">
        <div class="col-md-12">
            <div class="wide-banner cnt-strip">
                <div class="image"> <img class="img-responsive" src="http://placehold.it/848x214" alt=""> </div>
                <div class="new-label">
                    <div class="text">NEW</div>
                </div>
                <!-- /.new-label -->
            </div>
            <!-- /.wide-banner -->
        </div>
        <!-- /.col -->

    </div>
    <!-- /.row -->
</div>
<?php }
}
?>