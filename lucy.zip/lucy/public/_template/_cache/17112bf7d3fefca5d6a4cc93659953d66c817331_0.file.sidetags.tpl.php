<?php /* Smarty version 3.1.24, created on 2017-01-16 19:26:13
         compiled from "/var/www/html/lucy/public/_template/front/sidetags.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:131714370587d1045122645_68583058%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '17112bf7d3fefca5d6a4cc93659953d66c817331' => 
    array (
      0 => '/var/www/html/lucy/public/_template/front/sidetags.tpl',
      1 => 1484590665,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '131714370587d1045122645_68583058',
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_587d10451350a9_43206629',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_587d10451350a9_43206629')) {
function content_587d10451350a9_43206629 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '131714370587d1045122645_68583058';
?>
<div class="sidebar-widget product-tag wow fadeInUp">
    <h3 class="section-title">Product tags</h3>
    <div class="sidebar-widget-body outer-top-xs">
        <div class="tag-list"> <a class="item" title="Phone" href="category.html">Phone</a> <a class="item active" title="Vest" href="category.html">Vest</a> <a class="item" title="Smartphone" href="category.html">Smartphone</a> <a class="item" title="Furniture" href="category.html">Furniture</a> <a class="item" title="T-shirt" href="category.html">T-shirt</a> <a class="item" title="Sweatpants" href="category.html">Sweatpants</a> <a class="item" title="Sneaker" href="category.html">Sneaker</a> <a class="item" title="Toys" href="category.html">Toys</a> <a class="item" title="Rose" href="category.html">Rose</a> </div>
        <!-- /.tag-list -->
    </div>
    <!-- /.sidebar-widget-body -->
</div><?php }
}
?>