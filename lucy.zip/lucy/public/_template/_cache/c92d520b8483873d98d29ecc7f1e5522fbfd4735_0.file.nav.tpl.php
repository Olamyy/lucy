<?php /* Smarty version 3.1.24, created on 2017-03-01 02:10:55
         compiled from "/var/www/html/lucy/public/_template/front/registry/couple/preview/nav.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:156861550458b61f9f7a7537_20094663%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c92d520b8483873d98d29ecc7f1e5522fbfd4735' => 
    array (
      0 => '/var/www/html/lucy/public/_template/front/registry/couple/preview/nav.tpl',
      1 => 1488298254,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '156861550458b61f9f7a7537_20094663',
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_58b61f9f7aa906_47919425',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_58b61f9f7aa906_47919425')) {
function content_58b61f9f7aa906_47919425 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '156861550458b61f9f7a7537_20094663';
?>
</div>

</div>
</header>
            <button class="col-xs-6 col-sm-6 col-md-6 pull-right preview-cart text-center" data-toggle="modal" data-target="#carts">
                cart
            </button>
<?php }
}
?>