<?php /* Smarty version 3.1.24, created on 2017-02-21 12:47:34
         compiled from "/var/www/html/lucy/public/_template/front/middlebanner.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:122298698858ac28d6e662c9_20077031%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9b69927b5ac3ae1ffdebe63146a9dd12c76e6461' => 
    array (
      0 => '/var/www/html/lucy/public/_template/front/middlebanner.tpl',
      1 => 1487677328,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '122298698858ac28d6e662c9_20077031',
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_58ac28d6e6aca2_06401665',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_58ac28d6e6aca2_06401665')) {
function content_58ac28d6e6aca2_06401665 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '122298698858ac28d6e662c9_20077031';
?>
<div class="wide-banners wow fadeInUp outer-bottom-xs">
    <div class="row">
        <div class="col-md-12">
            <div class="wide-banner cnt-strip">
                <div class="image"> <img class="img-responsive" src="http://placehold.it/848x214" alt=""> </div>
                <div class="new-label">
                    <div class="text">NEW</div>
                </div>
                <!-- /.new-label -->
            </div>
            <!-- /.wide-banner -->
        </div>
        <!-- /.col -->

    </div>
    <!-- /.row -->
</div>
<?php }
}
?>