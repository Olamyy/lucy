<?php /* Smarty version 3.1.24, created on 2017-02-24 18:10:51
         compiled from "/var/www/html/lucy/public/_template/front/registry/couple/dashboard/mainsliders.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:166350298458b0691bf11ea9_31428722%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '83319bf8bb90db05cf769ad7e2f9c6902c1dfc1e' => 
    array (
      0 => '/var/www/html/lucy/public/_template/front/registry/couple/dashboard/mainsliders.tpl',
      1 => 1487677328,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '166350298458b0691bf11ea9_31428722',
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_58b0691c0090b9_34057126',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_58b0691c0090b9_34057126')) {
function content_58b0691c0090b9_34057126 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '166350298458b0691bf11ea9_31428722';
?>

<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
    <div id="hero">
        <div id="owl-main" class="owl-carousel owl-inner-nav owl-ui-sm">
            <div class="item" style="background-image: url(http://placehold.it/840x340);">
                <div class="container-fluid">
                    <div class="caption bg-color vertical-center text-left">
                    </div>
                    <!-- /.caption -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /.item -->

            <div class="item" style="background-image: url(http://placehold.it/840x340);">
                <div class="container-fluid">
                    <!-- /.caption -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /.item -->

        </div>
        <!-- /.owl-carousel -->
    </div>
    <div class="info-boxes wow fadeInUp">
        <div class="info-boxes-inner">
            <div class="row">
                <div class="col-md-6 col-sm-4 col-lg-4">
                    <div class="info-box">
                        <div class="row">
                            <div class="col-xs-12">
                                <h4 class="info-box-heading green">money back</h4>
                            </div>
                        </div>
                        <h6 class="text">30 Days Money Back Guarantee</h6>
                    </div>
                </div>
                <!-- .col -->

                <div class="hidden-md col-sm-4 col-lg-4">
                    <div class="info-box">
                        <div class="row">
                            <div class="col-xs-12">
                                <h4 class="info-box-heading green">free shipping</h4>
                            </div>
                        </div>
                        <h6 class="text">Shipping on orders over N99</h6>
                    </div>
                </div>
                <!-- .col -->

                <div class="col-md-6 col-sm-4 col-lg-4">
                    <div class="info-box">
                        <div class="row">
                            <div class="col-xs-12">
                                <h4 class="info-box-heading green">Special Sale</h4>
                            </div>
                        </div>
                        <h6 class="text">Extra N5 off on all items </h6>
                    </div>
                </div>
                <!-- .col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.info-boxes-inner -->

<?php }
}
?>