<?php /* Smarty version 3.1.24, created on 2017-05-15 20:44:40
         compiled from "/home/terragon/Sites/lucy/public/_template/front/registry/couple/dashboard/side.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:797049034591a0528e899e4_88886995%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3b345c8a01bf4b41033adf9caac9a408107c5ef5' => 
    array (
      0 => '/home/terragon/Sites/lucy/public/_template/front/registry/couple/dashboard/side.tpl',
      1 => 1494871087,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '797049034591a0528e899e4_88886995',
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_591a0528e94a03_64352410',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_591a0528e94a03_64352410')) {
function content_591a0528e94a03_64352410 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '797049034591a0528e899e4_88886995';
?>
<div class="body-content outer-top-vs" id="top-banner-and-menu">
    <div class="container">
        <div class="row">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-3 sidebar">
                        <?php echo $_smarty_tpl->getSubTemplate ("./couplesmalldetails.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

                        <?php echo $_smarty_tpl->getSubTemplate ("./wizard.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

                </div>

<?php }
}
?>