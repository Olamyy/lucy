<?php /* Smarty version 3.1.24, created on 2017-01-24 08:25:14
         compiled from "/var/www/html/lucy/public/_template/front/specialdeals.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:19018258985887015a4d7e63_13271530%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ed6e72221110d17efed8bae0911e7807ef3af2ad' => 
    array (
      0 => '/var/www/html/lucy/public/_template/front/specialdeals.tpl',
      1 => 1485241659,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19018258985887015a4d7e63_13271530',
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_5887015a4d8e53_76740867',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5887015a4d8e53_76740867')) {
function content_5887015a4d8e53_76740867 ($_smarty_tpl) {

}
}
?>