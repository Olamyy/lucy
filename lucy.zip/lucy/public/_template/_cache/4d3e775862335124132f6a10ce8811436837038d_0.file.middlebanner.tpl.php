<?php /* Smarty version 3.1.24, created on 2017-02-14 19:29:32
         compiled from "/var/www/html/lucyregistry/public/_template/front/middlebanner.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:202497743758a34c8c25f309_75812837%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4d3e775862335124132f6a10ce8811436837038d' => 
    array (
      0 => '/var/www/html/lucyregistry/public/_template/front/middlebanner.tpl',
      1 => 1487096653,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '202497743758a34c8c25f309_75812837',
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_58a34c8c260440_62245207',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_58a34c8c260440_62245207')) {
function content_58a34c8c260440_62245207 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '202497743758a34c8c25f309_75812837';
?>
<div class="wide-banners wow fadeInUp outer-bottom-xs">
    <div class="row">
        <div class="col-md-12">
            <div class="wide-banner cnt-strip">
                <div class="image"> <img class="img-responsive" src="http://placehold.it/848x214" alt=""> </div>
                <div class="strip strip-text">
                    <div class="strip-inner">
                        <h2 class="text-right">Promo Message<br>
                            <span class="shopping-needs">Save up to x% off</span></h2>
                    </div>
                </div>
                <div class="new-label">
                    <div class="text">NEW</div>
                </div>
                <!-- /.new-label -->
            </div>
            <!-- /.wide-banner -->
        </div>
        <!-- /.col -->

    </div>
    <!-- /.row -->
</div>
<?php }
}
?>