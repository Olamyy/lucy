<?php /* Smarty version 3.1.24, created on 2017-05-15 20:27:50
         compiled from "public/_template/front/registry/birthday.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:125842705591a013649a1c3_75105500%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '692668ba50b4bccffc29855c468d4349fd87297f' => 
    array (
      0 => 'public/_template/front/registry/birthday.tpl',
      1 => 1494871087,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '125842705591a013649a1c3_75105500',
  'variables' => 
  array (
    'BASE_URL' => 0,
    'error' => 0,
    'err' => 0,
    'user_session' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_591a0136992fe9_17820705',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_591a0136992fe9_17820705')) {
function content_591a0136992fe9_17820705 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '125842705591a013649a1c3_75105500';
echo $_smarty_tpl->getSubTemplate ('../header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<?php echo $_smarty_tpl->getSubTemplate ('../navmenu.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<div class="breadcrumb">
    <div class="container">
        <div class="breadcrumb-inner">
            <ul class="list-inline list-unstyled">
                <li><a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
">Home</a></li>
                <li><a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
registry">Registry</a></li>
                <li class='active'>Registry Details</li>
            </ul>
        </div><!-- /.breadcrumb-inner -->
    </div><!-- /.container -->
</div><!-- /.breadcrumb -->

<div class="body-content">
    <div class="container">
        <div class="sign-in-page">
            <div class="row">
                <!-- Sign-in -->
                <div class="col-md-12 col-sm-6 sign-in">
                    <h4 class="">Start Your Registry</h4>
                    <p class="">Let's get to know you</p>
                    <?php if ((($tmp = @$_smarty_tpl->tpl_vars['error']->value)===null||$tmp==='' ? '' : $tmp)) {?>
                        <div class="alert alert-danger">
                            <strong>Oops! Something went wrong</strong>
                            <?php
$_from = $_smarty_tpl->tpl_vars['error']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['err'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['err']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['err']->value) {
$_smarty_tpl->tpl_vars['err']->_loop = true;
$foreach_err_Sav = $_smarty_tpl->tpl_vars['err'];
?>
                                <p><?php echo $_smarty_tpl->tpl_vars['err']->value;?>
</p>
                            <?php
$_smarty_tpl->tpl_vars['err'] = $foreach_err_Sav;
}
?>
                        </div>
                    <?php }?>
                    <?php if ((($tmp = @$_smarty_tpl->tpl_vars['user_session']->value)===null||$tmp==='' ? '' : $tmp)) {?>
                    <?php }?>
                    <form class="register-form outer-top-xs" role="form" method="post" action="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
registry/init/birthday">
                        <h4 class="">Profile Details</h4>
                        <div class="form-group">
                            <label class="info-title" for="name">Your name<span>*</span></label>
                            <input type="text" name="name" required placeholder="First and last name"
                                   class="form-control unicase-form-control text-input" id="name" >
                        </div>
                        <div class="form-group">
                            <label class="info-title" for="name">Event Venue</label>
                            <input type="text" name="venue" required placeholder="Venue(Optional)"
                                   class="form-control unicase-form-control text-input" id="venue" >
                        </div>
                        <br>
                        <h4 class="">Registry Details</h4>
                        <br>
                        <label for="basic-url">Your registry URL<span>*</span></label>
                        <div class="input-group">
                            <span class="input-group-addon" id="basic-addon3" style="color: grey"><?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
index.php/registry/</span>
                            <input type="text" name="registry_url_tag" class="form-control" id="basic-url" aria-describedby="basic-addon3" placeholder="Your registry URL tag">
                        </div>
                        <br>
                        <div class="form-group">
                            <label class="info-title" for="event_date"><?php if ($_smarty_tpl->tpl_vars['user_session']->value[0]['regType'] == 'wedding') {?>Wedding <?php } else { ?>Event <?php }?> Date</label>
                            <input type="text" name="event_date" placeholder="DD-MM-YYYY"  class="form-control unicase-form-control text-input" id="event_date" >
                        </div>
                        <div class="form-group">
                            <input type="checkbox" aria-label="" id="NoDate">
                            <label class="info-title" for="NoDate"><?php if ($_smarty_tpl->tpl_vars['user_session']->value[0]['regType'] == 'wedding') {?>We <?php } else { ?>I <?php }?>haven't picked a date yet</div>
                        </div>
                        <br>
                        <button type="submit" class="btn-upper btn btn-primary checkout-page-button">Next</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $_smarty_tpl->getSubTemplate ("../footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>