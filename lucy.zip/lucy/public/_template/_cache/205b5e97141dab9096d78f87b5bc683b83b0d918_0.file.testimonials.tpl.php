<?php /* Smarty version 3.1.24, created on 2017-02-14 19:29:32
         compiled from "/var/www/html/lucyregistry/public/_template/front/testimonials.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:167103121658a34c8c208e02_61566612%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '205b5e97141dab9096d78f87b5bc683b83b0d918' => 
    array (
      0 => '/var/www/html/lucyregistry/public/_template/front/testimonials.tpl',
      1 => 1487096653,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '167103121658a34c8c208e02_61566612',
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_58a34c8c209474_39195430',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_58a34c8c209474_39195430')) {
function content_58a34c8c209474_39195430 ($_smarty_tpl) {

}
}
?>