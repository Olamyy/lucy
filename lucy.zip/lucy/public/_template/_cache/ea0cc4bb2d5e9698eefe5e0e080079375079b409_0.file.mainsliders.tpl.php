<?php /* Smarty version 3.1.24, created on 2017-02-21 17:01:38
         compiled from "/var/www/html/lucyreg/public/_template/front/mainsliders.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:152770129458ac6462986b47_63304006%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ea0cc4bb2d5e9698eefe5e0e080079375079b409' => 
    array (
      0 => '/var/www/html/lucyreg/public/_template/front/mainsliders.tpl',
      1 => 1487677328,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '152770129458ac6462986b47_63304006',
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_58ac646298a0c1_70477171',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_58ac646298a0c1_70477171')) {
function content_58ac646298a0c1_70477171 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '152770129458ac6462986b47_63304006';
?>

<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
    <div id="hero">
        <div id="owl-main" class="owl-carousel owl-inner-nav owl-ui-sm">
            <div class="item" style="background-image: url(http://placehold.it/840x340);">
                <div class="container-fluid">
                    <div class="caption bg-color vertical-center text-left">
                    </div>
                    <!-- /.caption -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /.item -->

            <div class="item" style="background-image: url(http://placehold.it/840x340);">
                <div class="container-fluid">
                    <!-- /.caption -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /.item -->

        </div>
        <!-- /.owl-carousel -->
    </div>
<?php }
}
?>