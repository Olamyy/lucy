<?php /* Smarty version 3.1.24, created on 2017-01-24 08:08:11
         compiled from "/var/www/html/lucy/public/_template/front/sidenewsletter.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:7549709195886fd5bec2b31_49306645%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '715e985a1a73ecdc32ae5da6a0ab361d56083217' => 
    array (
      0 => '/var/www/html/lucy/public/_template/front/sidenewsletter.tpl',
      1 => 1485241688,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7549709195886fd5bec2b31_49306645',
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_5886fd5bec3153_65850278',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5886fd5bec3153_65850278')) {
function content_5886fd5bec3153_65850278 ($_smarty_tpl) {

}
}
?>