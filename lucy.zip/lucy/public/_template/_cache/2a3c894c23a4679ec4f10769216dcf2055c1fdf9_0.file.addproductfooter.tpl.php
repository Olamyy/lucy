<?php /* Smarty version 3.1.24, created on 2017-05-16 15:47:16
         compiled from "/home/terragon/Sites/lucy/public/_template/admin/product/addproductfooter.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:831111864591b10f4a860d5_62485327%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2a3c894c23a4679ec4f10769216dcf2055c1fdf9' => 
    array (
      0 => '/home/terragon/Sites/lucy/public/_template/admin/product/addproductfooter.tpl',
      1 => 1494871087,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '831111864591b10f4a860d5_62485327',
  'variables' => 
  array (
    'BASE_URL' => 0,
    'SMARTY_VIEW_FOLDER' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_591b10f4ad3ce2_73327197',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_591b10f4ad3ce2_73327197')) {
function content_591b10f4ad3ce2_73327197 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '831111864591b10f4a860d5_62485327';
?>
<!-- /#wrap -->
<!-- global scripts-->
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;
echo $_smarty_tpl->tpl_vars['SMARTY_VIEW_FOLDER']->value;?>
/admin/assets/js/components.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;
echo $_smarty_tpl->tpl_vars['SMARTY_VIEW_FOLDER']->value;?>
/admin/assets/js/custom.js"><?php echo '</script'; ?>
>
<!-- end of global scripts-->
<!--Plugin scripts-->
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;
echo $_smarty_tpl->tpl_vars['SMARTY_VIEW_FOLDER']->value;?>
/admin/assets/vendors/bootstrapvalidator/js/bootstrapValidator.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;
echo $_smarty_tpl->tpl_vars['SMARTY_VIEW_FOLDER']->value;?>
/admin/assets/vendors/twitter-bootstrap-wizard/js/jquery.bootstrap.wizard.min.js"><?php echo '</script'; ?>
>
<!--End of plugin scripts-->
<!--Page level scripts-->
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;
echo $_smarty_tpl->tpl_vars['SMARTY_VIEW_FOLDER']->value;?>
/admin/assets/js/pages/wizard.js"><?php echo '</script'; ?>
>


<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;
echo $_smarty_tpl->tpl_vars['SMARTY_VIEW_FOLDER']->value;?>
/admin/assets/vendors/fileinput/js/fileinput.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;
echo $_smarty_tpl->tpl_vars['SMARTY_VIEW_FOLDER']->value;?>
/admin/assets/vendors/fileinput/js/theme.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;
echo $_smarty_tpl->tpl_vars['SMARTY_VIEW_FOLDER']->value;?>
/admin/assets/js/form.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;
echo $_smarty_tpl->tpl_vars['SMARTY_VIEW_FOLDER']->value;?>
/admin/assets/js/pages/form_elements.js"><?php echo '</script'; ?>
>

<!-- end page level scripts -->
</body>

</html><?php }
}
?>