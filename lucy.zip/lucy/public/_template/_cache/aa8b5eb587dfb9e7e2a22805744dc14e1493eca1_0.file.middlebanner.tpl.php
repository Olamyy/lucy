<?php /* Smarty version 3.1.24, created on 2017-02-21 17:01:38
         compiled from "/var/www/html/lucyreg/public/_template/front/middlebanner.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:106558435258ac6462b63592_15523792%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'aa8b5eb587dfb9e7e2a22805744dc14e1493eca1' => 
    array (
      0 => '/var/www/html/lucyreg/public/_template/front/middlebanner.tpl',
      1 => 1487677328,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '106558435258ac6462b63592_15523792',
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_58ac6462b68348_74635307',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_58ac6462b68348_74635307')) {
function content_58ac6462b68348_74635307 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '106558435258ac6462b63592_15523792';
?>
<div class="wide-banners wow fadeInUp outer-bottom-xs">
    <div class="row">
        <div class="col-md-12">
            <div class="wide-banner cnt-strip">
                <div class="image"> <img class="img-responsive" src="http://placehold.it/848x214" alt=""> </div>
                <div class="new-label">
                    <div class="text">NEW</div>
                </div>
                <!-- /.new-label -->
            </div>
            <!-- /.wide-banner -->
        </div>
        <!-- /.col -->

    </div>
    <!-- /.row -->
</div>
<?php }
}
?>