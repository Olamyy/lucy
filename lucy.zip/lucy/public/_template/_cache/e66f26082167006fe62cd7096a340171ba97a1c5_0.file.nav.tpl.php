<?php /* Smarty version 3.1.24, created on 2017-05-17 09:50:39
         compiled from "/home/terragon/Sites/lucy/public/_template/front/registry/couple/preview/nav.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:718994264591c0edfe6b681_02900871%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e66f26082167006fe62cd7096a340171ba97a1c5' => 
    array (
      0 => '/home/terragon/Sites/lucy/public/_template/front/registry/couple/preview/nav.tpl',
      1 => 1495011035,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '718994264591c0edfe6b681_02900871',
  'variables' => 
  array (
    'BASE_URL' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_591c0edfe6ef08_67238281',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_591c0edfe6ef08_67238281')) {
function content_591c0edfe6ef08_67238281 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '718994264591c0edfe6b681_02900871';
?>
</div>

</div>
</header>
            <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
registry/dashboard"> <button class="col-xs-6 col-sm-6 col-md-1 pull-left back-to-dashboard text-center">
                Dashboard
            </button></a>
<button class="col-xs-6 col-sm-6 col-md-1 pull-right preview-cart text-center" data-toggle="modal" data-target="#carts">
                cart
            </button>

<?php }
}
?>