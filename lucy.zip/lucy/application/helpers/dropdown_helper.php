<?php
/**
 * Created by PhpStorm.
 * User: lekanterragon
 * Date: 7/12/16
 * Time: 1:33 PM
 */


if(!defined('BASEPATH')) exit('No direct script access allowed');

function listClub($club, $league){

}