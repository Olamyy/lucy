<?php
/**
 * Created by PhpStorm.
 * User: lekanterragon
 * Date: 6/25/16
 * Time: 6:54 AM
 */

function asset_url(){
    return base_url().'assets/';
}