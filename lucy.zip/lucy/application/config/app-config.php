<?php
// Codeigniter access check, remove it for direct use
if( !defined( 'BASEPATH' ) ) exit( 'No direct script access allowed' );

$config["app_name"] = "Lucy";
$config["store_address"] = "12A Mabinuori Dawodu Street Gbagada Estate Phase 1, Lagos.";
$config["store_email"] = "info@lucy.ng";
$config["store_mobile"] = "tel: 0909-0001-509";
$config["store_fb"] = "";
$config["store_twitter"] = "";
$config["admin_username"] = "lucy";
$config["admin_password"] = "admin";
