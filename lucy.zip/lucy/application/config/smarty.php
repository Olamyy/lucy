<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['smarty_view_folder'] = 'public/_template';
$config['upload_folder'] = 'public/_template/uploads/files/';
$config['user-db-config'] = FALSE;