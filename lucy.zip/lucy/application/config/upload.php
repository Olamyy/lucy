<?php
/**
 * Created by PhpStorm.
 * User: terragon
 * Date: 5/16/17
 * Time: 4:31 PM
 */

$config["upload_path"] = FCPATH. "public/_templates/uploads";
$config["allowed_types"] = 'jpg|png|jpeg';
$config["overwrite"] = TRUE;
